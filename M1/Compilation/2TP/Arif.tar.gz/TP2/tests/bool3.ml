if 2 != 0 then 3 + 4 else 5 * 6
